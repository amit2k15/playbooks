<?php

if(isset($_POST['submit']))
      {
          $name = $_POST['name'];
          $email = $_POST['email'];
		  $application = $_POST['application'];
		  $bu= $_POST['bu'];
		  $tool= $_POST['tool'];
		  $type= $_POST['type'];
		  $feature= $_POST['feature'];
          $message = $_POST['message'];

          $host = "apvrd35618";
          $username = "orx_survey";
          $password = "321gue$$!T";
          $db = "orx_survey";
          $conn = mysqli_connect($host, $username, $password, $db);
if (!$con)
          {
die("Connection failed!" . mysqli_connect_error());
          }
          $query = "INSERT INTO form (id, username, email, application, bu, tool, type, feature, message VALUES $username, $email, $application, $bu, $tool, $type, $feature, $message";
          $run = mysqli_query($conn, $query);
if (run)
          {
echo"Success";
          }
mysqli_close($conn);
      }


?>